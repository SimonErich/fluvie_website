import 'package:flutter/material.dart' hide Animation, Clip, Image, Tween;
import 'package:fluvie/fluvie.dart';

Video build() {
  return Video(
    size: VideoSize(160, 160),
    audio: [Audio.music('assets/music.wav', volume: 0.4, fadeIn: 500.ms, fadeOut: 500.ms)],
    scenes: [
      Scene(
        duration: 1.5.seconds,
        background: Background.gradient(
          [Color(0xFF2C3E50), Color(0xFF000000)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        children: [
          ElementId(
            id: 'titleText',
            child: Text(
              'Milo\'s Playtime',
              style: TextStyle(color: Color(0xFFFFFFFF), fontSize: 18, fontWeight: FontWeight.bold),
            ).animate([Animation.fadeIn(duration: 1.seconds, delay: 0.2.seconds)]),
          ),
        ],
      ),
      Scene(
        duration: 2.5.seconds,
        background: Background.color(Color(0xFFE0E0E0)),
        children: [
          ElementId(
            id: 'playClip',
            child: Placed(
              placement: Placement(x: 0.5, y: 0.45, width: 0.8, height: 0.8),
              child: Clip.asset('assets/play.mp4', fit: BoxFit.contain, audio: ClipAudio.muted())
                  .animate([
                    Animation.fadeIn(duration: 0.5.seconds),
                  ], window: TimeRange(0.seconds, 2.seconds)),
            ),
          ),
          ElementId(
            id: 'redBall',
            child: Placed(
              placement: Placement(x: 0.7, y: 0.7, width: 0.2, height: 0.2),
              child: Image.asset('assets/ball.png', fit: BoxFit.contain).animate([
                Animation.pop(duration: 0.5.seconds),
              ], window: TimeRange(0.2.seconds, 2.2.seconds)),
            ),
          ),
          ElementId(
            id: 'captionText',
            child: Placed(
              placement: Placement(x: 0.5, y: 0.85),
              child:
                  Text(
                    'Playing with the red ball.',
                    style: TextStyle(color: Color(0xFF333333), fontSize: 18),
                  ).animate([
                    Animation.fadeIn(duration: 0.5.seconds),
                  ], window: TimeRange(0.5.seconds, 2.seconds)),
            ),
          ),
        ],
      ),
    ],
  );
}
