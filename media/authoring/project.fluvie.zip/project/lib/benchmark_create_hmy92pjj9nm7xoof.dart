import 'package:flutter/material.dart' hide Animation, Clip, Image, Tween;
import 'package:fluvie/fluvie.dart';

Video build() {
  return Video(
    size: VideoSize(160, 160),
    audio: [
      Audio.music(
        'assets/music.wav',
        volume: 0.3,
        fadeIn: 0.5.seconds,
        fadeOut: 0.5.seconds,
        loop: true,
      ),
    ],
    scenes: [
      Scene(
        duration: 1.5.seconds,
        background: Background.gradient(
          [Color(0xFF34495E), Color(0xFF2C3E50)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        children: [
          ElementId(
            id: 'title',
            child: Text(
              'Milo\'s Playtime',
              style: TextStyle(color: Color(0xFFFFFFFF), fontSize: 18, fontWeight: FontWeight.bold),
            ).animate([Animation.fadeIn(duration: 1.seconds, delay: 0.2.seconds)]),
          ),
        ],
      ),
      Scene(
        duration: 2.5.seconds,
        background: Background.color(Color(0xFFECF0F1)),
        children: [
          ElementId(
            id: 'redBall',
            child: Placed(
              placement: Placement(x: 0.5, y: 0.5, width: 0.3, height: 0.3),
              child: Image.asset('assets/ball.png').animate([
                Animation.pop(duration: 0.5.seconds, delay: 0.2.seconds),
                Animation.drift(delay: 0.7.seconds),
              ]),
            ),
          ),
          ElementId(
            id: 'playClip',
            child: Placed(
              placement: Placement(x: 0.5, y: 0.5, width: 0.8, height: 0.8),
              child: Clip.asset('assets/play.mp4').animate([
                Animation.fadeIn(duration: 0.5.seconds),
              ], window: TimeRange(0.5.seconds, 2.5.seconds)),
            ),
          ),
        ],
      ),
    ],
  );
}
